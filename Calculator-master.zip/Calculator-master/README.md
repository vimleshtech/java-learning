# Calculator App
This application created with Java Swing, 
## The images below is a preview of the application
### Without Color
![calc](https://user-images.githubusercontent.com/24855117/35707512-4d8db146-07aa-11e8-873d-b959e89ba1fc.JPG)
### With Color
![calc2](https://user-images.githubusercontent.com/24855117/35707545-69bb5670-07aa-11e8-91f8-56036edd1851.JPG)
