package questions;


public class k1 {
	
	k1(double d,double e, double f)
	{	
		double si = (d*e*f)/100;
		System.out.println("float "+si);
	}
	k1(int a, int b, int t)
	{
		int si = (a*b*t)/100;
		System.out.println("Integer "+si);
		
	}
	
	

	public static void main(String[] args) {
		
		
		
		k1 g = new k1(12.45,45.45,75.455);
		
	}

}
