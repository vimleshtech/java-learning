package questions;

public class b76_4 {

	public static void main(String[] args) {
		int a=1;
		for(int i=1;i<100;i++)
		{

			a=i*i+i-1;
			System.out.println(a);
		}
	}

}
