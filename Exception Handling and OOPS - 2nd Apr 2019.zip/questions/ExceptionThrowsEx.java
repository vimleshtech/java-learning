package questions;

import java.io.FileNotFoundException;
import java.io.FileReader;

public class ExceptionThrowsEx {

	public static void main(String[] args) throws FileNotFoundException {
		// TODO Auto-generated method stub

		FileReader fr = new FileReader("c://abcd/a.txt");
		
	}

}
