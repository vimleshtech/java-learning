package questions;

public class b76_1 {

	public static void main(String[] args) {
		int number=256;
		int i;		
		for(i=2; i<=number;)
		{		 
			System.out.println(i);
			i=i*2;	
				
		}
	}

}
