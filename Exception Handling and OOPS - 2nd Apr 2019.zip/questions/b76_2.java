package questions;

public class b76_2 {

	public static void main(String[] args) {
		int i=1,sum=1;
		while(i<=13)
		{
			
			sum+=3;
			System.out.println(sum);
			i++;
		}
		
	}

}
