package questions;

import java.nio.file.FileAlreadyExistsException;
import java.util.Scanner;

public class ExcepionExample {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Scanner s =new Scanner(System.in);
		int n,d,o;
		
		while(true)
		{
			try
			{
				System.out.println("enter data");
				n = s.nextInt();
				
				System.out.println("enter data");
				d = s.nextInt();
				if(d<0)
				{
					Exception ex = new Exception("divisor cannot be less than 0");
					throw ex;
					
				}
				//div
				o = n/d;		
				System.out.println(o);
				break;
			}
			catch (ArithmeticException e) {
				// TODO: handle exception
			}
		
			catch (ArrayIndexOutOfBoundsException e) {
				// TODO: handle exception
			}
			catch (Exception e) {//Exception is inbuilt class ,e is object
				// TODO: handle exception
				System.out.println("there is data issue , plz try again "+e);
			}
			finally {
				System.out.println("end of block");
			}
		}
		//add	
		o =n+d;
		System.out.println("sum of two numebrs "+o);

	}

}
