package questions;

public class b76_5 {

	public static void main(String[] args) {
		int i,n=5;
		
		for(i=1;i<=n;i++)
		{
			System.out.print("(");
			
			for(int j=1;j<=i;j++)
			{
				
				if(j<i)
				System.out.print(j+"+");
				else
				System.out.print(j);
				
			}
			System.out.print(")+");
		}
	}

}
