package questions;

import java.util.Scanner;

public class emp {
	private int Ecode;
	private String Ename;
	private float Basicsalary;
	private float Hra;
	private float Da ;
	private float Ta;
	private float Grosssalary;
	private float It;
	private float Pf;
	private float Netsalary;
	
	public void Input()
	{
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter Employee Name");
		Ename = sc.next();
		System.out.println("Enter Employee Code");
		Ecode = sc.nextInt();
		System.out.println("Enter Employee basic salary");
		Basicsalary = sc.nextInt();
		
	}
	
	public void calc()
	{
		Hra = (float) (Basicsalary*.40);
		Da  = (float) (Basicsalary*.20);
		Ta = (float) (Basicsalary*.10);
		Grosssalary = Basicsalary + Hra + Da + Ta;
		It = (float) (Grosssalary*.20);
		Pf = (float) (Grosssalary*.10);
		Netsalary = Grosssalary - (It + Pf);
	}
	
	public void disp()
	{
		System.out.println("x------------------------------------x");
		System.out.println("Employee Code : " + Ecode);
		System.out.println("Employee Name : " + Ename);
		System.out.println("Employee basic salary : " + Basicsalary);
		System.out.println("Employee Hra : " + Hra);
		System.out.println("Employee Da : " + Da);
		System.out.println("Employee Ta : " + Ta);
		System.out.println("Employee Grosssalary : " + Grosssalary);
		System.out.println("Employee It : " + It);
		System.out.println("Employee Pf : " + Pf);
		System.out.println("Employee Netsalary : " + Netsalary);
		System.out.println("x------------------------------------x");
	}

	public static void main(String[] args) {
//		emp a = new emp();
//		a.Input();
//		a.calc();
//		a.disp();
		
		emp a[] = new emp[5];
		for(int i=0 ; i<5;i++)
		{
			a[i] = new emp();
			a[i].Input();
		}

		for(int i=0 ; i<5;i++)
		{
			a[i].calc();
		}
  
		for(int i=0 ; i<5;i++)
		{
			a[i].disp();
		}
	}

}
