package questions;

import java.util.Scanner;

public class j5 {
	private int roll_no;
	private String address;
	private String name;
	private String city;
	private String country;

	public void getData()
	{
		Scanner sc = new Scanner(System.in);
		Scanner sc1 = new Scanner(System.in);
		System.out.println("enter the student address");
		address = sc1.nextLine();
		System.out.println("enter the student name");
		name = sc1.nextLine();
		System.out.println("enter the student city");
		city = sc1.nextLine();
		System.out.println("enter the student country");
		country = sc1.nextLine();
		System.out.println("enter the student roll_no");
		roll_no = sc.nextInt();
		
		
	}
	public void displayData()
	{
		System.out.println("roll_no : "+roll_no);
		System.out.println("address : "+address);
		System.out.println("name : "+name);
		System.out.println("city : "+city);
		System.out.println("country : "+country);
		
	}
	public int Retroll()
	{
		
//		System.out.println("return roll no" + roll_no);
		return roll_no;
		
	}
	
	public int rolldetails()
	{
		Scanner sc = new Scanner(System.in);
		System.out.println("enter the student roll_no");
		roll_no = sc.nextInt();
		return roll_no;
	}

	public static void main(String[] args) {
		
		
		
		// take multiple value
		j5 j1[]=new j5[5];
		
		
		for(int i=1;i<5;i++)
		{
			j1[i] = new j5(); // initilize new object
			j1[i].getData();
			
		}
		for(int i=1;i<5;i++)
		{
			
			j1[i].displayData();
			int r=j1[i].Retroll();
			System.out.println(r);
		}
	
		// enter roll no
		j5 d =new j5();
		int f = d.rolldetails();
		boolean ismatch=false;
		
		for(int i=1;i<5;i++)
		{
			
			int r=j1[i].Retroll();
			if(r==f)
			{
				j1[i].displayData();
				ismatch=true;
			}
			
		}
		if(!ismatch)
		{
			System.out.println("Not found");
		}
		
		//sort
		for(int i=1;i<5;i++)
		{
			
			for(int j=i+1;j<5;j++)
			{
				if(j1[i].Retroll() >j1[j].Retroll() ) {
					j5  temp = j1[i];
					j1[i]=j1[j];
					j1[j] = temp;
				}
				
				
			}	
			
			
		}
		

		for(int i=1;i<5;i++)
		{
		
			j1[i].displayData();
		}
	}

}
