package questions;

import java.util.Scanner;

public class xyz {
	float principal, rate, totalamount;
	int  time;
	Scanner sc = new Scanner(System.in);
	
	xyz()
	{
		System.out.println("enter the principal");		
		principal = sc.nextInt();
		
		System.out.println("enter the principal");		
		rate = sc.nextInt();
		
		System.out.println("enter the time ");		
		time = sc.nextInt();
		
		
		
	}
	xyz(float p, float r)
	{
		principal =p;
		rate =r;
		
		System.out.println("enter the time ");		
		time = sc.nextInt();
				
	}
	xyz(float p, float r, int t)
	{
		principal =p;
		rate =r;
		time =t;
		
		
	}
	public void clc()
	{
		totalamount = principal*rate*time;
	}
	public void disp()
	{
		System.out.println("Toatal amount "+this.totalamount);
	}

	public static void main(String[] args) {
		
		xyz o1=new xyz();
		o1.clc();
		o1.disp();
		
		
		xyz o2=new xyz(111233,3);
		o2.clc();
		o2.disp();
		
		xyz o3=new xyz(1133,3,3);
		o3.clc();
		o3.disp();
		
	}
	

}
