package questions;

public class b76_3 {

	public static void main(String[] args) {
		int i=1,sum=1;
		while(i<=13)
		{
			
			sum+=3;
			if(sum%2==0)
			{
				System.out.println(sum*-1);
			}
			else
			{
				System.out.println(sum);
			}
			
			i++;
		}

	}

}
