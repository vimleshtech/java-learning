package questions;
import java.util.Scanner;
public class b8 {

	public static void main(String[] args) {
		int salary;
		float da=0, hra=0.0f, totalSal=0;
		Scanner sc = new Scanner(System.in);
		System.out.println("enter your salary");
		salary = sc.nextInt();
		if(salary>=5000 && salary<=10000)
		{
			da=(float) (salary * 10/100);
			hra=(float) (salary*5/100);
			totalSal=salary+da+hra;
		}
		else if(salary>=10001 && salary<=15000)
		{
			da=(float) (salary* (15/100));
			hra=(float) (salary* (8/100));
			totalSal=salary+da+hra;
		}
		sc.close();
		System.out.println(da+"and "+hra + "Total"+totalSal);
	}

}
